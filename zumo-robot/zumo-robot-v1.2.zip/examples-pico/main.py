"""
main.py - the minimalist main.py - just avoids the motors to starts.

* Author(s):  Meurisse D. from MCHobby (shop.mchobby.be).

See project source @ https://github.com/mchobby/pyboard-driver/tree/master/zumo-robot
REQUIRES library zumoshield.py in the project source
"""

from zumoshield import ZumoMotor
from machine import Pin

z = ZumoMotor() # will stop the motors

# Light Up the Pico onbloard LED LED
Pin(25,Pin.OUT).on()
